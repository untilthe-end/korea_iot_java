package org.example.test0710;

public class 자바기초이론문제 {
}

/*

Q1. D
Q2. A
Q3. D
Q4. B
Q5. B
Q6. C
Q7. C
Q8. C
Q9. D
Q10. D
Q11. 2
Q12. 오버라이딩이 제대로 안되었음! - void sound() 로 그대로 사용해야함!
 */
